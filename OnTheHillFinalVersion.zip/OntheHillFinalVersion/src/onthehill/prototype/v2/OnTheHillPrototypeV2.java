/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package onthehill.prototype.v2;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author tpa13n
 */
public class OnTheHillPrototypeV2 {
    private static String name;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SplashbackScreen1 SSS = new SplashbackScreen1();
        try {  
            Thread.sleep(3000);
        } catch (InterruptedException ex) {
            Logger.getLogger(SplashbackScreen1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public static void setName (String name){
        OnTheHillPrototypeV2.name = name;
    }
    public static String getName (){
        return OnTheHillPrototypeV2.name;
    }
    
}
